# Doña Rutina · Corrección y nuevo lote

Escena 4: los dos frames de escena-04-cureta-v2 sustituyen los anteriores con bisturí. Incluye referencia de cureta y frase revisada.

Escenas 5–7: seis frames nuevos de pomada, cultivo y plata en frames-escenas-05-07-v1. FRASES-Y-REACCIONES.md explica entradas y cambios de expresión.

Ocho frames en total, más la imagen de referencia del objeto. Imágenes fijas generadas con la herramienta integrada; sin vídeo ni voz.
